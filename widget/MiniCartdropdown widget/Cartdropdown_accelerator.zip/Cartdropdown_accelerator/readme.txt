Openpay Cart drop down accelerator module is for displaying widgets regarding Openpay promotion. This module is compatible with Magento version 1.x.
This module is functional if and only if the Openpay Payment Method module(Aopen_Openpay) is already running in your website.

This module represents :
  Cart drop down accelerator - will appear on the mini cart section if your amount in cart is less than openpay minimum amount

For setting up this module, please refer to 'installation-guide.pdf' available inside this module.
