Openpay Price calculator Widgets module is for displaying widgets regarding Openpay promotion. This module is compatible with Magento version 1.x.

This module represents :
  Price calculator widget - will appear on the product listing page

For setting up this module, please refer to 'installation-guide.pdf' available inside this module.
