<?php   
class Openpay_PriceCalculatorWidget_Block_Index extends Mage_Core_Block_Template{   





}