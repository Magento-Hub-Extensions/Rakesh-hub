Openpay Product calculator Widgets module is for displaying widgets regarding Openpay promotion. This module is compatible with Magento version 1.x.

This module represents :
  Product calculator widget - will appear on the product details page

For setting up this module, please refer to 'installation-guide.pdf' available inside this module.
