<?php
class Openpay_ProductCalculatorWidget_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 