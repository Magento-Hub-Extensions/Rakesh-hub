<?php
class Openpay_Checkoutwidget_Model_Payment_Openpay extends Aopen_Openpay_Model_Payment_Openpay
{
	protected $_formBlockType = 'checkoutwidget/index';

}

