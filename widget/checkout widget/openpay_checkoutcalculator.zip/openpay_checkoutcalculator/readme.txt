Openpay Checkout Widgets module is for displaying widgets regarding Openpay promotion. This module is compatible with Magento version 1.x.
This module is functional if and only if the Openpay Payment Method module(Aopen_Openpay) is already running in your website.

This module represents the following widgets :
1. Checkout widget right col - will appear on the right panel of chck out page if order amount is less than openpay minimum amount.
2. Checkout widget with openpay payment methos on selecting the payment method radio button.

For setting up this module, please refer to 'installation-guide.pdf' available inside this module.
